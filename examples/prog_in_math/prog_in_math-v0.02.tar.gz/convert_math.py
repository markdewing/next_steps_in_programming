#!/usr/bin/env python 

import sys
from xml.dom import minidom, Node
from mathml import *
from lang_c import *
import re
import unicodedata
import greek

# Copyright 2005 by Mark Dewing
# Version 0.02

# Converts content MathML to various forms
#  1. Text (somewhat TeX-like) 
#  2. Presentation MathML
#  3. C++


# Input is file.xml, presentation MathML is in file.xhtml
#  C++ is in file.cpp


# The functions handle_expr and handle_declare output the text format
# The functions handle_expr_ml and handle_declare_ml output the presentation
#  MathML
# The functions handle_expr_cpp2 and handle_declare_cpp2 output C++


class function_information:
  def __init__(self):
    self.is_index = 0
    self.name = ""
    self.xml_node = None
    self.is_ffi = False
    self.ffi_name = ""
    self.is_time_series = False
    self.is_constant = False
    self.defer_processing = 0
    self.do_replace = False
    self.replace_name = ""

#index_func_list = {}
#ffi_func_list = {}

func_list = {}
node_replace_list = {}


# transformation functions

def handle_expr(node,need_paren=0):
  out_str = ""
  skip = 1
  nterm = 0
  need_term = 0
  might_need_paren = 0
  if is_node_name(node,"apply"):
    op = get_apply_op(node)
    if (op == "plus"): 
       op_str = "+"
       need_term = 1
    if (op == "minus"): 
       op_str = "-"
       need_term = 1
    if (op == "times"): 
       op_str = "*"
       might_need_paren = 1
    if (op == "divide"): 
       op_str = "/"
       might_need_paren = 1
    if (op == "power"): 
       op_str = "^"
       might_need_paren = 1
    if (op == "root"):
       out_str += "sqrt ("
       skip = len(node.childNodes)
       for n2 in node.childNodes[2:]:
         if is_element_node(n2):
           out_str += handle_expr(n2)[0]
       out_str += ")"   
    if (op == "sum"): 
       skip = 7
       out_str += "sum"
       (bvar,low_limit,up_limit) = get_limit_nodes(node)
       out_str += "_{" + handle_expr(bvar.childNodes[0])[0]
       out_str += "=" + handle_expr(low_limit.childNodes[0])[0]
       out_str += "}^"
       for n2 in up_limit.childNodes:
         if is_element_node(n2):
           (tmp_str,nt) = handle_expr(n2)
           if (nt > 1):
              out_str += "{" + tmp_str + "}"
           else:
             out_str += tmp_str
         
       out_str += " "
    if (op == "ci"): 
       func_name = get_apply_op_value(node)
       out_str += func_name + "("
       skip = len(node.childNodes)
       tmp_str = ""
       for n2 in node.childNodes[2:]:
         if is_element_node(n2): 
           if (tmp_str):
             out_str += tmp_str
             out_str += ","
           tmp_str = handle_expr(n2)[0]
       out_str += tmp_str + ")"
   
    next_str = ""
    if (need_paren):
      out_str += "("
    for n1 in node.childNodes[skip:]:
      if is_element_node(n1): 
         if need_term:
           nterm+=1
         if (next_str != ""):
           out_str += next_str
           out_str += op_str
         next_str = handle_expr(n1,might_need_paren)[0]
         #print 'next_str = ',next_str.encode('utf-8')
    out_str += next_str
    if (need_paren):
      out_str += ")"
    return (out_str,nterm)
  if is_node_name(node,"ci"):
    #print "ci = ",node.childNodes[0].nodeValue.encode('utf-8')
    #print "ci = ",greek.convert_symbols(node.childNodes[0].nodeValue)
    return  (greek.convert_symbols(node.childNodes[0].nodeValue),0)
    #return  (node.childNodes[0].nodeValue.encode('utf-8'),0)
  if is_node_name(node,"cn"):
    return  (node.childNodes[0].nodeValue,0)
     
  return ""


# create a function call
def make_function_call_cpp2(maybe_name,node,cfi):
  global func_list
  func_name = maybe_name
  if func_list.has_key(maybe_name):
    if func_list[maybe_name].is_ffi:
      func_name = func_list[maybe_name].ffi_name
  body_list = []
  func_call = c_function_call(func_name)
  for arg1 in iterateElementNodes(node.childNodes[2:]):
    (body_arg,ret_arg) = handle_expr_cpp2(arg1,cfi)
    func_call.arglist.append(ret_arg)
    if body_arg:
      for b in body_arg:
        body_list.append(b)
  return (body_list,func_call)

def compare_summands(node1, node2):
  if node1.nodeType != node2.nodeType:
    return False
  if node1.nodeName != node2.nodeName:
    return False
  if len(node1.childNodes) != len(node2.childNodes):
    return False
  for i in range(0,len(node1.childNodes)):
    b = compare_summands(node1.childNodes[i],node2.childNodes[i])
    if not(b):
      return False
  
  return True

# Node list is a list of pointer to the sums
def merge_sums_cpp2(node_list,cfi):
  body_list = []
  sum_var_list = []
  is_duplicate = []
  #for node in node_list:
  for i in range(0,len(node_list)):
    node = node_list[i]
    is_unique = True
    indx = 0
    for j in range(0,i):
      if compare_summands(node,node_list[j]):
        is_unique = False
        indx = j
        break
    if is_unique:
      sum_var = cfi.get_new_variable("sum")
      tmp_decl = c_decl("double",sum_var,c_var("0.0"))
      body_list.append(tmp_decl)
      is_duplicate.append(False)
    else:
      sum_var = sum_var_list[indx] 
      is_duplicate.append(True)
      
    sum_var_list.append(sum_var)
  if len(node_list) == 0:
    return None
  node = node_list[0]
  (bvar,low_limit,up_limit) = get_limit_nodes(node)
  bvar_expr = handle_expr_cpp2(bvar.childNodes[0],cfi)[1]
  low_expr = handle_expr_cpp2(low_limit.childNodes[0],cfi,0)[1]
  #up_expr = handle_expr_cpp2(up_limit.childNodes[0],cfi)[1]
  up_expr = None
  for up1 in up_limit.childNodes:
    if is_element_node(up1):
      up_expr = handle_expr_cpp2(up1,cfi,0)[1]
  if not cfi.has_variable(bvar_expr.name):
    bvar_decl = c_decl("int",bvar_expr)
    cfi.add_variable(bvar_expr.name)
    body_list.append(bvar_decl)
  for_start = c_assign_stmt(bvar_expr,low_expr)
  for_end = c_expr(c_expr.C_OP_LE,bvar_expr,up_expr)
  for_inc = c_expr(c_expr.C_OP_POST_INCR,bvar_expr)
  for_expr = c_for(for_start,for_end,for_inc)


     
  body_list.append(for_expr)

  # find the time series function and replace it
  node = node_list[0]
  for n in findElement(node,"apply"):
    op = get_apply_op(n)
    if (op == "ci"): 
       global func_list
       maybe_name = get_apply_op_value(n)
       func_name = maybe_name
       if func_list.has_key(maybe_name):
          if func_list[maybe_name].is_time_series:
            tmp_name = cfi.get_new_variable("tmp")
            func_list[maybe_name].replace_name = tmp_name
            (body_list2,func_call) = make_function_call_cpp2(func_name,n,cfi)
            #func_call = c_function_call(maybe_name)
            #for arg1 in iterateElementNodes(n.childNodes[2:]):
            #  (body_arg,ret_arg) = handle_expr_cpp2(arg1,cfi)
            #  func_call.arglist.append(ret_arg)
            #  for_expr.append_body(body_arg)
            for_expr.append_body(body_list2)
            #tmp_assign = c_assign_stmt(c_var(tmp_name),func_call,c_assign_stmt.C_ASSIGN_EQUAL)
            tmp_assign = c_decl("double",tmp_name,func_call)
            for_expr.body.append(tmp_assign)
            func_list[maybe_name].do_replace = True

    


  for i in range(0,len(node_list)):
    node = node_list[i]
    sum_var = sum_var_list[i]
    n3 = getElementNode(node.childNodes,4)
    if not(is_duplicate[i]):
      (body_body,body_ret) = handle_expr_cpp2(n3,cfi)

      for_body1 = c_assign_stmt(c_var(sum_var),body_ret,c_assign_stmt.C_ASSIGN_PLUS)
      for_expr.append_body(body_body)
      for_expr.body.append(for_body1)
  return (body_list,sum_var_list)

# do some optimization for small integer values of the exponent

def handle_power_cpp2(node,cfi):
  pow_body = []
  n1 = getElementNode(node.childNodes,1)
  (pow_body1,pow_ret1) = handle_expr_cpp2(n1,cfi)
  n2 = getElementNode(node.childNodes,2)
  (pow_body2,pow_ret2) = handle_expr_cpp2(n2,cfi,0)

  if isinstance(pow_ret2,c_var):
    if is_integer(pow_ret2.name):
      pow_value = int(pow_ret2.name)
      if pow_value == 1:
         return (pow_body1,pow_ret1)
      if pow_value == 2:
         if c_is_simple(pow_ret1):
           pow_ret3 = c_expr(c_expr.C_OP_TIMES,pow_ret1,pow_ret1)
           return (pow_body1,pow_ret3)
         else:
           tmp_var = cfi.get_new_variable("tmp")
           cfi.add_variable(tmp_var)
           tmp_assign = c_decl("double",tmp_var,pow_ret1)
           pow_body1.append(tmp_assign)
           if pow_body2:
             for pw2 in pow_body2:
               pow_body1.append(pw2)
           pow_ret3 = c_expr(c_expr.C_OP_TIMES,c_var(tmp_var),c_var(tmp_var))
           return (pow_body1,pow_ret3)

  pow_func = c_function_call("pow") 
  if pow_body1:
    for pw1 in pow_body1:
      pow_body.append(pw1)
  if pow_body2:
    for pw2 in pow_body2:
      pow_body.append(pw2)

  pow_func.arglist.append(pow_ret1)
  pow_func.arglist.append(pow_ret2)

  return (pow_body,pow_func)
   

def handle_expr_cpp2(node,cfi,do_double=1):
  global node_replace_list
  if node_replace_list.has_key(node):
    return (None,node_replace_list[node])

  if is_node_name(node,"apply"):
    op = get_apply_op(node)
    op_type = None
    if (op == "plus"): 
      op_type = c_expr.C_OP_PLUS
    if (op == "minus"): 
      op_type = c_expr.C_OP_MINUS
    if (op == "times"): 
      op_type = c_expr.C_OP_TIMES
    if (op == "divide"): 
      op_type = c_expr.C_OP_DIVIDE
    if (op == "power"):
      (pow_body,pow_func) = handle_power_cpp2(node,cfi)
      return (pow_body,pow_func)
    if (op == "root"):
      n1 = getElementNode(node.childNodes,1)
      (root_body1,root_ret1) = handle_expr_cpp2(n1,cfi)
      root_func = c_function_call("sqrt") 
      root_func.arglist.append(root_ret1)
      return (root_body1,root_func)
      
    if (op == "sum"):
      body_list = []
      sum_var = cfi.get_new_variable("sum")
      tmp_decl = c_decl("double",sum_var,c_var("0.0"))
      body_list.append(tmp_decl)
      (bvar,low_limit,up_limit) = get_limit_nodes(node)
      bvar_expr = handle_expr_cpp2(bvar.childNodes[0],cfi)[1]
      low_expr = handle_expr_cpp2(low_limit.childNodes[0],cfi,0)[1]
      #up_expr = handle_expr_cpp2(up_limit.childNodes[0],cfi)[1]
      up_expr = None
      for up1 in up_limit.childNodes:
        if is_element_node(up1):
          up_expr = handle_expr_cpp2(up1,cfi,0)[1]
      if not cfi.has_variable(bvar_expr.name):
        bvar_decl = c_decl("int",bvar_expr)
        cfi.add_variable(bvar_expr.name)
        body_list.append(bvar_decl)
      for_start = c_assign_stmt(bvar_expr,low_expr)
      for_end = c_expr(c_expr.C_OP_LE,bvar_expr,up_expr)
      for_inc = c_expr(c_expr.C_OP_POST_INCR,bvar_expr)
      for_expr = c_for(for_start,for_end,for_inc)

     
      body_list.append(for_expr)
      n3 = getElementNode(node.childNodes,4)
      (body_body,body_ret) = handle_expr_cpp2(n3,cfi)

      for_body1 = c_assign_stmt(c_var(sum_var),body_ret,c_assign_stmt.C_ASSIGN_PLUS)
      if body_body:
        for b1 in body_body:
          for_expr.body.append(b1)
      #for_expr.append_body(body_body)
      for_expr.body.append(for_body1)
      return (body_list,c_var(sum_var))
    if (op == "ci"): 
       global func_list
       maybe_name = get_apply_op_value(node)
       func_name = maybe_name
       if func_list.has_key(maybe_name):
          if func_list[maybe_name].do_replace:
             return (None,c_var(func_list[maybe_name].replace_name))
       (body_list,func_call) = make_function_call_cpp2(func_name,node,cfi)
       return (body_list,func_call)

    n1 = getElementNode(node.childNodes,1)
    (body,ret) = handle_expr_cpp2(n1,cfi,do_double)
    n2 = getElementNode(node.childNodes,2)
    (body2,ret2) = handle_expr_cpp2(n2,cfi,do_double)
    body_list = []
    if body:
      for b1 in body:
        body_list.append(b1)
    if body2:
      for b2 in body2:
        body_list.append(b2)
    return (body_list,c_expr(op_type,ret,ret2))
  if is_node_name(node,"ci"):
    name = node.childNodes[0].nodeValue
    return  (None,c_var(greek.convert_symbols(name)))
  if is_node_name(node,"cn"):
    number = node.childNodes[0].nodeValue
    if do_double and is_integer(number):
      return (None,c_var(number+".0"))
    return  (None,c_var(number))
  return (None,None)

def handle_expr_ml(node,doc,out_node,need_paren=0):
  skip = 1
  might_need_paren = 0
  if is_node_name(node,"apply"):
    op = get_apply_op(node)
    if (op == "plus"): 
       op_str = "+"
    if (op == "minus"): 
       op_str = "-"
    if (op == "times"): 
       op_str = ""
       might_need_paren = 1
    if (op == "divide"): 
       op_str = ""
       might_need_paren = 1
       skip = 5
       frac_node = createChildElement(doc,out_node,"mfrac") 
       num_node = createChildElement(doc,frac_node,"mrow")
       denom_node = createChildElement(doc,frac_node,"mrow")
       node1 = getElementNode(node.childNodes,1)
       node2 = getElementNode(node.childNodes,2)
       handle_expr_ml(node1,doc,num_node,might_need_paren)
       handle_expr_ml(node2,doc,denom_node,might_need_paren)
       might_need_paren = 0
    if (op == "power"):
       op_str = ""
       might_need_paren = 1
       skip = 5
       node1 = getElementNode(node.childNodes,1)
       node2 = getElementNode(node.childNodes,2)
       sup_node = createChildElement(doc,out_node,"msup") 
       base_node = createChildElement(doc,sup_node,"mrow")
       handle_expr_ml(node1,doc,base_node,might_need_paren)
       handle_expr_ml(node2,doc,sup_node,might_need_paren)

    if (op == "root"):
       skip = len(node.childNodes)
       mroot_node = createChildElement(doc,out_node,"msqrt")
       for n2 in iterateElementNodes(node.childNodes[2:]):
         handle_expr_ml(n2,doc,mroot_node)
       
    if (op == "sum"): 
       op_str = "my_ampersand;Sum;"
       skip = 7
       need_paren = 0
       sum_node = createChildElement(doc,out_node,"munderover")
       createChildTextElement(doc,sum_node,"mo",op_str)
       (bvar,low_limit,up_limit) = get_limit_nodes(node)
       lower_node = createChildElement(doc,sum_node,"mrow")
       handle_expr_ml(bvar.childNodes[0],doc,lower_node)
       createChildTextElement(doc,lower_node,"mo","=")
       handle_expr_ml(low_limit.childNodes[0],doc,lower_node)
       upper_node = createChildElement(doc,sum_node,"mrow")
       for n2 in iterateElementNodes(up_limit.childNodes):
         handle_expr_ml(n2,doc,upper_node)


    if (op == "ci"):
       func_name = get_apply_op_value(node)
       global func_list
       is_index_func = 0
       if func_list.has_key(func_name):
         is_index_func = func_list[func_name].is_index

       if is_index_func:
         msub_node = createChildElement(doc,out_node,"msub")
         createChildTextElement(doc,msub_node,"mi",func_name)
       else:
         createChildTextElement(doc,out_node,"mi",func_name)
       skip = len(node.childNodes)
       #fence_node = createChildElement(doc,out_node,"mfenced")
       if is_index_func:
         fence_node = createChildElement(doc,msub_node,"mrow")
       else:
         fence_node = createChildElement(doc,out_node,"mrow")
         createChildTextElement(doc,fence_node,"mo","(")
       len1 = get_len(iterateElementNodes(node.childNodes[2:]))
       idx1 = 0
       for n2 in iterateElementNodes(node.childNodes[2:]):
         handle_expr_ml(n2,doc,fence_node)
         idx1 += 1
         if (idx1 < len1):
           createChildTextElement(doc,fence_node,"mo",",")
       if not(is_index_func):
         createChildTextElement(doc,fence_node,"mo",")")
   
    len1 = get_len(iterateElementNodes(node.childNodes[skip:]))
    if (need_paren and len1 > 0):
      createChildTextElement(doc,out_node,"mo","(")
      
    prev_node = None
    for n1 in node.childNodes[skip:]:
      if is_element_node(n1): 
         #showNode(n1)
         if (prev_node != None):
           handle_expr_ml(prev_node,doc,out_node,might_need_paren)
           if (op_str != ""):
             createChildTextElement(doc,out_node,"mo",op_str)
         prev_node = n1
    handle_expr_ml(prev_node,doc,out_node,might_need_paren)
    if (need_paren and len1 > 0):
      createChildTextElement(doc,out_node,"mo",")")
    return 
  if is_node_name(node,"ci"):
    new_node = createChildTextElement(doc,out_node,"mi",node.childNodes[0].nodeValue)
    return  
  if is_node_name(node,"cn"):
    new_node = createChildTextElement(doc,out_node,"mn",node.childNodes[0].nodeValue)
    return 
     
  return ""
   


def handle_fn_declare(node):
  out =  get_func_name(node) 
  len1 = get_len(get_arg_list(get_lambda_node(node)))
  if (len1 > 0):
    out += "("
  idx = 0
  for a in get_arg_list(get_lambda_node(node)):
    out += a 
    idx += 1
    if (idx < len1):
      out += ","
  #out = out[0:-1] 
  if (len1 > 0):
    out += ")" 
  out += " = "
  out += handle_expr(get_expr_node(get_lambda_node(node)))[0]
  print greek.convert_symbols(out)

def handle_ffi_declare(node):
  out = get_func_name(node)
  ffi_name = get_named_child_value(node,"ffi_name")
  print "ffi: ",greek.convert_symbols(out)," = ",ffi_name

def handle_declare(node):
  fn_type_attr = node.getAttribute("type")
  if fn_type_attr:
    if fn_type_attr == "fn":
      handle_fn_declare(node)
    else: 
      if fn_type_attr == "ffi":
        handle_ffi_declare(node)

#------------------  C++

def handle_fn_declare_cpp2(node):
  is_constant = False
  constant_attr = node.getAttribute("constant")
  if constant_attr and constant_attr == "true":
    is_constant = True

  inp_attr = node.getAttribute("input")
  input_type = "double"
  if inp_attr:
    input_type = inp_attr

  output_attr = node.getAttribute("output")
  output_type = "double"
  do_double = 1
  if output_attr:
    output_type = output_attr
    if output_type == "int":
      do_double = 0
  

  cfi = c_function_info()
  c_tree = c_function_def("double",get_func_name(node))
  for a in get_arg_list(get_lambda_node(node)):
    c_arg1 = c_arg(input_type,a)
    c_tree.arglist.append(c_arg1)
  (cexpr,cret) = handle_expr_cpp2(get_expr_node(get_lambda_node(node)),cfi,do_double)
  if cexpr:
    for expr in cexpr:
      c_tree.expr_list.append(expr)
  if cret:
    ret = c_return_stmt(cret)
    c_tree.expr_list.append(ret)
  if is_constant:
     cconst = c_decl(output_type,get_func_name(node),cret)
     if not(cexpr):
       cexpr = []
     cexpr.append(cconst)
     out_str = ""
     for e1 in cexpr:
       out_str += e1.get_string()
     return out_str
  out_str = c_tree.get_string()
  return out_str

def handle_declare_cpp2(node):
  global func_list
  if func_list.has_key(get_func_name(node)):
     if func_list[get_func_name(node)].defer_processing == 1:
       return ""
  
  fn_type_attr = node.getAttribute("type")
  if fn_type_attr:
    if fn_type_attr == "fn":
      return handle_fn_declare_cpp2(node)
    else: 
      if fn_type_attr == "ffi":
        return handle_ffi_declare_cpp2(node)


def handle_ffi_declare_cpp2(node):
  return ""

def does_a_depend_on_b(a,b):
  for n in findElement(a.xml_node,"ci"):
    if a.name == n.childNodes[0].nodeValue:
      return True
  return False

# not implemented correctly
def order_by_dependencies(node_list):
  tmp_list = node_list
  for i in range(0,len(node_list)):
    for j in range(0,len(node_list)):
      if i != j:
        if does_a_depend_on_b(node_list[j],node_list[i]): 
          tmp = tmp_list[j]
          tmp_list[j] = tmp_list[i]
          tmp_list[i] = tmp

  return tmp_list


# currently functions with sums that need to be combined

def handle_deferred_cpp2():
  global func_list
  deferred_list = []
  for f in func_list.values():
    if f.defer_processing:
      deferred_list.append(f)

  if len(deferred_list) == 0:
    return ""

  new_name=""
  first = True
  for n in deferred_list:
    if first:
     first = False
    else:
     new_name += "_and_"
    new_name += n.name
  print "new name = ",new_name

  sum_list = []
  for f in deferred_list:
    for sop in find_apply_op(f.xml_node,"sum"):
      if sop != None:
        sum_list.append(sop)

  cfi = c_function_info()
  c_tree = c_function_def("void",new_name)
  for n in deferred_list:
    c_arg1 = c_arg("double",n.name,c_arg.C_ARG_REFERENCE)
    c_tree.arglist.append(c_arg1)


  (expr_list,sum_result_list) = merge_sums_cpp2(sum_list,cfi)
  for e in expr_list:
    c_tree.expr_list.append(e)

  global node_replace_list
  for i in range(0,len(sum_list)):
    node_replace_list[sum_list[i]] = c_var(sum_result_list[i])

  ordered_deferred_list = order_by_dependencies(deferred_list)

  for f in ordered_deferred_list:
    (body_list,result_value) = handle_expr_cpp2(get_expr_node(get_lambda_node(f.xml_node)),cfi)
    if body_list:
      for b in body_list:
        c_tree.expr_list.append(b)
    cassign1 = c_assign_stmt(c_var(f.name),result_value)
    c_tree.expr_list.append(cassign1)

  return c_tree.get_string()
  

#------------------  Presentation MathML

def handle_fn_declare_ml(doc,out_node,node):
  is_constant = False
  constant_attr = node.getAttribute("constant")
  if constant_attr and constant_attr == "true":
    is_constant = True

  is_index_func = 0
  index_attr = node.getAttribute("index")
  if index_attr and index_attr == "true":
    is_index_func = 1
  
  #math_node = .createElement("math")
  #doc.appendChild(math_node)
  math_node = createChildElement(doc,out_node,"math")
  a_str = "http://www.w3.org/1998/Math/MathML"
  math_node.attributes['xmlns'] = a_str
  # next line, make big math
  math_node.attributes['mode'] = "display"
  mrow_node = createChildElement(doc,math_node,"mrow")

  if is_index_func:
    msub_node = createChildElement(doc,mrow_node,"msub")
    createChildTextElement(doc,msub_node,"mi",get_func_name(node))
    msubrow_node = createChildElement(doc,msub_node,"mrow")
  else:
    createChildTextElement(doc,mrow_node,"mi",get_func_name(node))

  if not(is_constant):
    arg_list = get_arg_list(get_lambda_node(node))
    len1 = get_len(arg_list)
    if (len1 > 0):
      if is_index_func:
        for a in get_arg_list(get_lambda_node(node)):
          createChildTextElement(doc,msubrow_node,"mi",a)
      else:
        fence_node = createChildElement(doc,mrow_node,"mfenced")
        for a in get_arg_list(get_lambda_node(node)):
          createChildTextElement(doc,fence_node,"mi",a)

  createChildTextElement(doc,mrow_node,"mo","=")
    
  handle_expr_ml(get_expr_node(get_lambda_node(node)),doc,mrow_node)

def handle_ffi_declare_ml(doc,out_node,node):
  fn_name = get_func_name(node)
  ffi_name = get_named_child_value(node,"ffi_name")

  math_node = createChildElement(doc,out_node,"math")
  a_str = "http://www.w3.org/1998/Math/MathML"
  math_node.attributes['xmlns'] = a_str
  # next line, make big math
  math_node.attributes['mode'] = "display"
  mrow_node = createChildElement(doc,math_node,"mrow")
  createChildTextElement(doc,mrow_node,"mi",fn_name)
  createChildTextElement(doc,mrow_node,"mo","=")
  createChildTextElement(doc,mrow_node,"mi",ffi_name)

def handle_declare_ml(doc,out_node,node):
  fn_type_attr = node.getAttribute("type")
  if fn_type_attr:
    if fn_type_attr == "fn":
      handle_fn_declare_ml(doc,out_node,node)
    else: 
      if fn_type_attr == "ffi":
        handle_ffi_declare_ml(doc,out_node,node)
  
def process_function(node):
  global func_list
  fi = function_information()

  is_constant = False
  constant_attr = node.getAttribute("constant")
  if constant_attr and constant_attr == "true":
    fi.is_constant = True

  is_time_series = False
  time_series_attr = node.getAttribute("time_series")
  if time_series_attr and time_series_attr == "true":
    fi.is_time_series = True

  is_index_func = 0
  index_attr = node.getAttribute("index")
  if index_attr and index_attr == "true":
    fi.is_index = 1

  fn_type_attr = node.getAttribute("type")
  if fn_type_attr and fn_type_attr == "ffi":
    fi.is_ffi = True
    fi.ffi_name = get_named_child_value(node,"ffi_name")

  fi.name = get_func_name(node)
  fi.xml_node = node
  func_list[get_func_name(node)] = fi


def process_results(node):
  global func_list
  for n in iterateElementNodes(node.childNodes):
    if n.nodeName == "ci":
      name = n.childNodes[0].nodeValue
      if func_list.has_key(name):
        func_list[name].defer_processing=1



def main():
  file_in = sys.argv[1]
  doc = minidom.parse(file_in)
  node = doc.documentElement

  cpp_out = re.sub("\.xml$",".cpp",file_in)
  do_cpp_output = 0
  if cpp_out != file_in:
    do_cpp_output = 1
    cpp_output = open(cpp_out,"w")
 
  doc_out = minidom.Document()
  doc_type = minidom.DocumentType("html")
  doc_type.publicId = "-//W3C//DTD XHTML 1.1 plus MathML 2.0//EN"
  doc_type.systemId = "http://www.w3.org/TR/MathML2/dtd/xhtml-math11-f.dtd"
  doc_out.appendChild(doc_type)
  html_node = createChildElement(doc,doc_out,"html")
 
  html_node.attributes['xmlns'] = "http://www.w3.org/1999/xhtml"
  html_node.attributes['xmlns:math'] = "http://www.w3.org/1998/Math/MathML"
  body_node = createChildElement(doc,html_node,"body")

  # do a scan for function definitions
  for n in walkTree(node):
    if n.nodeType == Node.ELEMENT_NODE and n.nodeName == "math":
      for n3 in n.childNodes:
        if n3.nodeType == Node.ELEMENT_NODE and n3.nodeName == "declare":
          process_function(n3)
    if n.nodeType == Node.ELEMENT_NODE and n.nodeName == "results":
      process_results(n)

  #iterate over all the nodes
  for n in walkTree(node):
        if n.nodeType == Node.ELEMENT_NODE and n.nodeName == "math":
          for n3 in n.childNodes:
            if n3.nodeType == Node.ELEMENT_NODE and n3.nodeName == "declare":
              print handle_declare(n3) 
              handle_declare_ml(doc,body_node,n3) 
              if do_cpp_output:
                cpp_str = handle_declare_cpp2(n3)
                cpp_str += '\n'
                cpp_output.write(cpp_str)
            else:
              if n3.nodeType == Node.ELEMENT_NODE and n3.nodeName == "comment":
                body_node.appendChild(n3)
        else:
          if n.nodeType == Node.ELEMENT_NODE and n.nodeName == "comment":
            body_node.appendChild(n)

  cpp_str = handle_deferred_cpp2()
  cpp_str += '\n'
  cpp_output.write(cpp_str)
        
      
     

  # pick out just the math/declare nodes
  #for n in findElement(node,"math"):
  #  for n2 in findElement(n,"declare"):
  #    print handle_declare(n2) 
  #    handle_declare_ml(doc,body_node,n2) 
  #    if do_cpp_output:
  #      cpp_str = handle_declare_cpp2(n2)
  #      cpp_str += '\n'
  #      cpp_output.write(cpp_str)

  #print doc_out.toxml()
  #print doc_out.toprettyxml()
  s = doc_out.toprettyxml()
  #s = doc_out.toxml()
  s = s.replace("my_ampersand;","&")
  #s = s.replace(u'\u03be',"&#x3be;")
  #s = s.replace(u'\u03be',"&xi;")
  s = greek.convert_symbols(s,1)

  xhtml_out = re.sub("\.xml$",".xhtml",file_in)
  if xhtml_out != file_in:
      output = open(xhtml_out,"w")
      output.write(s)
      output.close()

  if do_cpp_output:
      cpp_output.close()

   
  #print s
 

if __name__ == '__main__':
  main()
