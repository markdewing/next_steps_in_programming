#!/usr/local/bin/python 

# Converts some unicode values to symbol names

# Copyright 2005 by Mark Dewing
# Version 0.02

# data obtained from http://www.w3.org/TR/2003/REC-MathML2-20031021/isogrk3.html
math_symbols = {
u"\u03B1" : "alpha",
u"\u03B2" : "beta",
u"\u03C7" : "chi",
u"\u0394" : "Delta",
u"\u03B4" : "delta",
u"\u03F5" : "epsilon",
u"\u03B5" : "varepsilon",
u"\u03B7" : "eta",
u"\u0393" : "Gamma",
u"\u03B3" : "gamma",
u"\u03DC" : "Digamma",
u"\u03DD" : "digamma",
u"\u03B9" : "iota",
u"\u03BA" : "kappa",
u"\u03F0" : "dikappa",
u"\u039B" : "Lambda",
u"\u03BB" : "lambda",
u"\u03BC" : "mu",
u"\u03BD" : "nu",
u"\u03A9" : "Omega",
u"\u03C9" : "omega",
u"\u03A6" : "Phi",
u"\u03D5" : "phi",
u"\u03C6" : "varphi",
u"\u03A0" : "Pi",
u"\u03C0" : "pi",
u"\u03D6" : "varpi",
u"\u03A8" : "Psi",
u"\u03C8" : "psi",
u"\u03C1" : "rho",
u"\u03F1" : "varrho",
u"\u03A3" : "Sigma",
u"\u03C3" : "sigma",
u"\u03C2" : "varsigma",
u"\u03C4" : "tau",
u"\u0398" : "Theta",
u"\u03B8" : "theta",
u"\u03D1" : "vartheta",
u"\u03D2" : "Upsilon",
u"\u03C5" : "upsilon",
u"\u039E" : "Xi",
u"\u03BE" : "xi",
u"\u03B6" : "zeta"
}

def convert_symbols(in_string,do_html=0):
  if not in_string:
    return ""
  out_str = ""
  for s in in_string:
    if math_symbols.has_key(s):
      if do_html:
        out_str += "&" + math_symbols[s] + ";"
      else:
        out_str += math_symbols[s]
    else:   
      out_str += s
  return out_str

if __name__ == "__main__":
  print convert_symbols("hi")
  print convert_symbols(u"\u03b1")


